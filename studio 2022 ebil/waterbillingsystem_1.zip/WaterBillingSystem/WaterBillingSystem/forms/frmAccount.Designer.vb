﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TxtProfile_Mname = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.txtMyUsername = New System.Windows.Forms.TextBox()
        Me.txtMyPassword = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.BtnProfile_Save = New System.Windows.Forms.Button()
        Me.TxtProfile_Phone = New System.Windows.Forms.TextBox()
        Me.TxtProfile_Fax = New System.Windows.Forms.TextBox()
        Me.TxtProfile_Fname = New System.Windows.Forms.TextBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.TxtProfile_Address = New System.Windows.Forms.TextBox()
        Me.TxtProfile_Mobile = New System.Windows.Forms.TextBox()
        Me.TxtProfile_Lname = New System.Windows.Forms.TextBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TxtProfile_Mname
        '
        Me.TxtProfile_Mname.Location = New System.Drawing.Point(197, 96)
        Me.TxtProfile_Mname.Name = "TxtProfile_Mname"
        Me.TxtProfile_Mname.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Mname.TabIndex = 40
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(117, 99)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(72, 13)
        Me.Label57.TabIndex = 59
        Me.Label57.Text = "Middle Name:"
        '
        'txtMyUsername
        '
        Me.txtMyUsername.Location = New System.Drawing.Point(197, 258)
        Me.txtMyUsername.Name = "txtMyUsername"
        Me.txtMyUsername.Size = New System.Drawing.Size(238, 20)
        Me.txtMyUsername.TabIndex = 46
        '
        'txtMyPassword
        '
        Me.txtMyPassword.Location = New System.Drawing.Point(197, 284)
        Me.txtMyPassword.Name = "txtMyPassword"
        Me.txtMyPassword.Size = New System.Drawing.Size(238, 20)
        Me.txtMyPassword.TabIndex = 47
        Me.txtMyPassword.UseSystemPasswordChar = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(130, 261)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(61, 13)
        Me.Label36.TabIndex = 57
        Me.Label36.Text = "Username :"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(130, 287)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(59, 13)
        Me.Label37.TabIndex = 56
        Me.Label37.Text = "Password :"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(131, 75)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(60, 13)
        Me.Label83.TabIndex = 54
        Me.Label83.Text = "First Name:"
        '
        'BtnProfile_Save
        '
        Me.BtnProfile_Save.Location = New System.Drawing.Point(197, 310)
        Me.BtnProfile_Save.Name = "BtnProfile_Save"
        Me.BtnProfile_Save.Size = New System.Drawing.Size(111, 23)
        Me.BtnProfile_Save.TabIndex = 48
        Me.BtnProfile_Save.Text = "Save"
        Me.BtnProfile_Save.UseVisualStyleBackColor = True
        '
        'TxtProfile_Phone
        '
        Me.TxtProfile_Phone.Location = New System.Drawing.Point(197, 180)
        Me.TxtProfile_Phone.Name = "TxtProfile_Phone"
        Me.TxtProfile_Phone.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Phone.TabIndex = 43
        '
        'TxtProfile_Fax
        '
        Me.TxtProfile_Fax.Location = New System.Drawing.Point(197, 206)
        Me.TxtProfile_Fax.Name = "TxtProfile_Fax"
        Me.TxtProfile_Fax.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Fax.TabIndex = 44
        '
        'TxtProfile_Fname
        '
        Me.TxtProfile_Fname.Location = New System.Drawing.Point(197, 72)
        Me.TxtProfile_Fname.Name = "TxtProfile_Fname"
        Me.TxtProfile_Fname.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Fname.TabIndex = 39
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(147, 183)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(44, 13)
        Me.Label85.TabIndex = 55
        Me.Label85.Text = "Phone :"
        '
        'TxtProfile_Address
        '
        Me.TxtProfile_Address.Location = New System.Drawing.Point(197, 148)
        Me.TxtProfile_Address.Name = "TxtProfile_Address"
        Me.TxtProfile_Address.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Address.TabIndex = 42
        '
        'TxtProfile_Mobile
        '
        Me.TxtProfile_Mobile.Location = New System.Drawing.Point(197, 232)
        Me.TxtProfile_Mobile.Name = "TxtProfile_Mobile"
        Me.TxtProfile_Mobile.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Mobile.TabIndex = 45
        '
        'TxtProfile_Lname
        '
        Me.TxtProfile_Lname.Location = New System.Drawing.Point(197, 122)
        Me.TxtProfile_Lname.Name = "TxtProfile_Lname"
        Me.TxtProfile_Lname.Size = New System.Drawing.Size(238, 20)
        Me.TxtProfile_Lname.TabIndex = 41
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(161, 209)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(30, 13)
        Me.Label89.TabIndex = 52
        Me.Label89.Text = "Fax :"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(140, 151)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(51, 13)
        Me.Label90.TabIndex = 53
        Me.Label90.Text = "Address :"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(149, 235)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(42, 13)
        Me.Label91.TabIndex = 51
        Me.Label91.Text = "Mobie :"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(130, 125)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(61, 13)
        Me.Label92.TabIndex = 50
        Me.Label92.Text = "Last Name:"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(12, 3)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(108, 25)
        Me.Label82.TabIndex = 49
        Me.Label82.Text = "My Profile"
        '
        'frmAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(598, 381)
        Me.Controls.Add(Me.TxtProfile_Mname)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.txtMyUsername)
        Me.Controls.Add(Me.txtMyPassword)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label83)
        Me.Controls.Add(Me.BtnProfile_Save)
        Me.Controls.Add(Me.TxtProfile_Phone)
        Me.Controls.Add(Me.TxtProfile_Fax)
        Me.Controls.Add(Me.TxtProfile_Fname)
        Me.Controls.Add(Me.Label85)
        Me.Controls.Add(Me.TxtProfile_Address)
        Me.Controls.Add(Me.TxtProfile_Mobile)
        Me.Controls.Add(Me.TxtProfile_Lname)
        Me.Controls.Add(Me.Label89)
        Me.Controls.Add(Me.Label90)
        Me.Controls.Add(Me.Label91)
        Me.Controls.Add(Me.Label92)
        Me.Controls.Add(Me.Label82)
        Me.Name = "frmAccount"
        Me.Text = "ACCOUNT"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtProfile_Mname As TextBox
    Friend WithEvents Label57 As Label
    Friend WithEvents txtMyUsername As TextBox
    Friend WithEvents txtMyPassword As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents BtnProfile_Save As Button
    Friend WithEvents TxtProfile_Phone As TextBox
    Friend WithEvents TxtProfile_Fax As TextBox
    Friend WithEvents TxtProfile_Fname As TextBox
    Friend WithEvents Label85 As Label
    Friend WithEvents TxtProfile_Address As TextBox
    Friend WithEvents TxtProfile_Mobile As TextBox
    Friend WithEvents TxtProfile_Lname As TextBox
    Friend WithEvents Label89 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label91 As Label
    Friend WithEvents Label92 As Label
    Friend WithEvents Label82 As Label
End Class
