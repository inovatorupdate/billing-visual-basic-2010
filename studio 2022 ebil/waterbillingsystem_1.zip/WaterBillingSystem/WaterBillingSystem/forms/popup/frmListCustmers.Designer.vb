﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListCustmers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnAddCus_Save2 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TxtAddCus_Code = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TxtAddCus_NickName = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Phone = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Fname = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Address = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TxtAddCus_Mobile = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Lname = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.lbl = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(402, 179)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(61, 23)
        Me.Button1.TabIndex = 50
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnAddCus_Save2
        '
        Me.BtnAddCus_Save2.Location = New System.Drawing.Point(336, 179)
        Me.BtnAddCus_Save2.Name = "BtnAddCus_Save2"
        Me.BtnAddCus_Save2.Size = New System.Drawing.Size(60, 23)
        Me.BtnAddCus_Save2.TabIndex = 49
        Me.BtnAddCus_Save2.Text = "Save"
        Me.BtnAddCus_Save2.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 55)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(82, 13)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Customer Code:"
        '
        'TxtAddCus_Code
        '
        Me.TxtAddCus_Code.Location = New System.Drawing.Point(89, 52)
        Me.TxtAddCus_Code.Name = "TxtAddCus_Code"
        Me.TxtAddCus_Code.Size = New System.Drawing.Size(152, 20)
        Me.TxtAddCus_Code.TabIndex = 47
        Me.TxtAddCus_Code.Text = "code0"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(28, 81)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(60, 13)
        Me.Label32.TabIndex = 42
        Me.Label32.Text = "First Name:"
        '
        'TxtAddCus_NickName
        '
        Me.TxtAddCus_NickName.Location = New System.Drawing.Point(89, 104)
        Me.TxtAddCus_NickName.Name = "TxtAddCus_NickName"
        Me.TxtAddCus_NickName.Size = New System.Drawing.Size(152, 20)
        Me.TxtAddCus_NickName.TabIndex = 31
        '
        'TxtAddCus_Phone
        '
        Me.TxtAddCus_Phone.Location = New System.Drawing.Point(88, 130)
        Me.TxtAddCus_Phone.Name = "TxtAddCus_Phone"
        Me.TxtAddCus_Phone.Size = New System.Drawing.Size(153, 20)
        Me.TxtAddCus_Phone.TabIndex = 33
        '
        'TxtAddCus_Fname
        '
        Me.TxtAddCus_Fname.Location = New System.Drawing.Point(89, 78)
        Me.TxtAddCus_Fname.Name = "TxtAddCus_Fname"
        Me.TxtAddCus_Fname.Size = New System.Drawing.Size(152, 20)
        Me.TxtAddCus_Fname.TabIndex = 36
        '
        'TxtAddCus_Address
        '
        Me.TxtAddCus_Address.Location = New System.Drawing.Point(307, 104)
        Me.TxtAddCus_Address.Name = "TxtAddCus_Address"
        Me.TxtAddCus_Address.Size = New System.Drawing.Size(156, 20)
        Me.TxtAddCus_Address.TabIndex = 34
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(22, 107)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(66, 13)
        Me.Label35.TabIndex = 38
        Me.Label35.Text = "Nick Name :"
        '
        'TxtAddCus_Mobile
        '
        Me.TxtAddCus_Mobile.Location = New System.Drawing.Point(307, 130)
        Me.TxtAddCus_Mobile.Name = "TxtAddCus_Mobile"
        Me.TxtAddCus_Mobile.Size = New System.Drawing.Size(156, 20)
        Me.TxtAddCus_Mobile.TabIndex = 35
        '
        'TxtAddCus_Lname
        '
        Me.TxtAddCus_Lname.Location = New System.Drawing.Point(320, 78)
        Me.TxtAddCus_Lname.Name = "TxtAddCus_Lname"
        Me.TxtAddCus_Lname.Size = New System.Drawing.Size(143, 20)
        Me.TxtAddCus_Lname.TabIndex = 37
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(44, 133)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(44, 13)
        Me.Label39.TabIndex = 40
        Me.Label39.Text = "Phone :"
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.Location = New System.Drawing.Point(253, 107)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(51, 13)
        Me.lbl.TabIndex = 39
        Me.lbl.Text = "Address :"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(257, 133)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(44, 13)
        Me.Label38.TabIndex = 41
        Me.Label38.Text = "Mobile :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(247, 81)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(61, 13)
        Me.Label33.TabIndex = 43
        Me.Label33.Text = "Last Name:"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.Size = New System.Drawing.Size(473, 205)
        Me.DataGridView1.TabIndex = 8
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(385, 211)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(76, 25)
        Me.btnadd.TabIndex = 11
        Me.btnadd.Text = "add new"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Chartreuse
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.TextBox1.Location = New System.Drawing.Point(4, 214)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(156, 20)
        Me.TextBox1.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(166, 218)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 16)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "search"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.BtnAddCus_Save2)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Code)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_NickName)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Phone)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Fname)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Address)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Mobile)
        Me.GroupBox1.Controls.Add(Me.TxtAddCus_Lname)
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.lbl)
        Me.GroupBox1.Controls.Add(Me.Label38)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 257)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(461, 238)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "add customer"
        Me.GroupBox1.Visible = False
        '
        'frmListCustmers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(473, 242)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmListCustmers"
        Me.Text = "frmListCustmers"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents BtnAddCus_Save2 As Button
    Friend WithEvents Label23 As Label
    Friend WithEvents TxtAddCus_Code As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents TxtAddCus_NickName As TextBox
    Friend WithEvents TxtAddCus_Phone As TextBox
    Friend WithEvents TxtAddCus_Fname As TextBox
    Friend WithEvents TxtAddCus_Address As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents TxtAddCus_Mobile As TextBox
    Friend WithEvents TxtAddCus_Lname As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents lbl As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnadd As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
End Class
