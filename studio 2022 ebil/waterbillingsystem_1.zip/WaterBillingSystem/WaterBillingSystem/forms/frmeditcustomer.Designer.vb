﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmeditcustomer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbladdcus = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TxtAddCus_Code = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.BtnAddCus_Save = New System.Windows.Forms.Button()
        Me.TxtAddCus_NickName = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Phone = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Fname = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Address = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TxtAddCus_Mobile = New System.Windows.Forms.TextBox()
        Me.TxtAddCus_Lname = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.lbl = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbladdcus
        '
        Me.lbladdcus.BackColor = System.Drawing.Color.White
        Me.lbladdcus.Dock = System.Windows.Forms.DockStyle.Top
        Me.lbladdcus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladdcus.Location = New System.Drawing.Point(0, 0)
        Me.lbladdcus.Name = "lbladdcus"
        Me.lbladdcus.Size = New System.Drawing.Size(537, 40)
        Me.lbladdcus.TabIndex = 30
        Me.lbladdcus.Text = "Edit Customer"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(76, 84)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(82, 13)
        Me.Label23.TabIndex = 44
        Me.Label23.Text = "Customer Code:"
        '
        'TxtAddCus_Code
        '
        Me.TxtAddCus_Code.Enabled = False
        Me.TxtAddCus_Code.Location = New System.Drawing.Point(165, 81)
        Me.TxtAddCus_Code.Name = "TxtAddCus_Code"
        Me.TxtAddCus_Code.Size = New System.Drawing.Size(127, 20)
        Me.TxtAddCus_Code.TabIndex = 43
        Me.TxtAddCus_Code.Text = "0code"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(98, 113)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(60, 13)
        Me.Label32.TabIndex = 31
        Me.Label32.Text = "First Name:"
        '
        'BtnAddCus_Save
        '
        Me.BtnAddCus_Save.Location = New System.Drawing.Point(165, 266)
        Me.BtnAddCus_Save.Name = "BtnAddCus_Save"
        Me.BtnAddCus_Save.Size = New System.Drawing.Size(122, 23)
        Me.BtnAddCus_Save.TabIndex = 42
        Me.BtnAddCus_Save.Text = "Save"
        Me.BtnAddCus_Save.UseVisualStyleBackColor = True
        '
        'TxtAddCus_NickName
        '
        Me.TxtAddCus_NickName.Location = New System.Drawing.Point(165, 162)
        Me.TxtAddCus_NickName.Name = "TxtAddCus_NickName"
        Me.TxtAddCus_NickName.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_NickName.TabIndex = 38
        '
        'TxtAddCus_Phone
        '
        Me.TxtAddCus_Phone.Location = New System.Drawing.Point(165, 214)
        Me.TxtAddCus_Phone.Name = "TxtAddCus_Phone"
        Me.TxtAddCus_Phone.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_Phone.TabIndex = 40
        '
        'TxtAddCus_Fname
        '
        Me.TxtAddCus_Fname.Location = New System.Drawing.Point(165, 110)
        Me.TxtAddCus_Fname.Name = "TxtAddCus_Fname"
        Me.TxtAddCus_Fname.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_Fname.TabIndex = 29
        '
        'TxtAddCus_Address
        '
        Me.TxtAddCus_Address.Location = New System.Drawing.Point(165, 188)
        Me.TxtAddCus_Address.Name = "TxtAddCus_Address"
        Me.TxtAddCus_Address.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_Address.TabIndex = 39
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(92, 165)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(66, 13)
        Me.Label35.TabIndex = 32
        Me.Label35.Text = "Nick Name :"
        '
        'TxtAddCus_Mobile
        '
        Me.TxtAddCus_Mobile.Location = New System.Drawing.Point(165, 240)
        Me.TxtAddCus_Mobile.Name = "TxtAddCus_Mobile"
        Me.TxtAddCus_Mobile.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_Mobile.TabIndex = 41
        '
        'TxtAddCus_Lname
        '
        Me.TxtAddCus_Lname.Location = New System.Drawing.Point(165, 136)
        Me.TxtAddCus_Lname.Name = "TxtAddCus_Lname"
        Me.TxtAddCus_Lname.Size = New System.Drawing.Size(270, 20)
        Me.TxtAddCus_Lname.TabIndex = 33
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(111, 217)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(44, 13)
        Me.Label39.TabIndex = 34
        Me.Label39.Text = "Phone :"
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.Location = New System.Drawing.Point(107, 191)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(51, 13)
        Me.lbl.TabIndex = 35
        Me.lbl.Text = "Address :"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(111, 243)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(44, 13)
        Me.Label38.TabIndex = 36
        Me.Label38.Text = "Mobile :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(97, 139)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(61, 13)
        Me.Label33.TabIndex = 37
        Me.Label33.Text = "Last Name:"
        '
        'frmeditcustomer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 362)
        Me.Controls.Add(Me.lbladdcus)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.TxtAddCus_Code)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.BtnAddCus_Save)
        Me.Controls.Add(Me.TxtAddCus_NickName)
        Me.Controls.Add(Me.TxtAddCus_Phone)
        Me.Controls.Add(Me.TxtAddCus_Fname)
        Me.Controls.Add(Me.TxtAddCus_Address)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.TxtAddCus_Mobile)
        Me.Controls.Add(Me.TxtAddCus_Lname)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label33)
        Me.Name = "frmeditcustomer"
        Me.Text = "Customer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbladdcus As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents TxtAddCus_Code As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents BtnAddCus_Save As Button
    Friend WithEvents TxtAddCus_NickName As TextBox
    Friend WithEvents TxtAddCus_Phone As TextBox
    Friend WithEvents TxtAddCus_Fname As TextBox
    Friend WithEvents TxtAddCus_Address As TextBox
    Friend WithEvents Label35 As Label
    Friend WithEvents TxtAddCus_Mobile As TextBox
    Friend WithEvents TxtAddCus_Lname As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents lbl As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label33 As Label
End Class
